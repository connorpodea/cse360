module FloatingPointRecognizerTestbed {
	requires javafx.controls;
	
	opens floatingPointRecognizer to javafx.graphics, javafx.fxml;
}
