/**
 * 
 */
/**
 * 
 */
module ASUHellowWorldConsole {
}