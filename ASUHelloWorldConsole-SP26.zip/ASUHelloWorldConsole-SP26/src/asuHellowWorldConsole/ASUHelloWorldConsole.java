package asuHellowWorldConsole;

public class ASUHelloWorldConsole {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.out.println("by Lynn Robert Carter");
	}

}
