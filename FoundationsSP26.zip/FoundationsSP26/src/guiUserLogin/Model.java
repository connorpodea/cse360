package guiUserLogin;

public class Model {

}
