package MVCPostManagement;

import entityClasses.Post;
import database.Database;
import java.sql.SQLException;
import javafx.scene.layout.VBox;           // Essential
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;      // Essential
import javafx.scene.control.CheckBox;      // Essential
import javafx.scene.control.Label;         // Essential

/**
 * Handles user actions for creating, viewing, editing,
 * deleting, and replying to posts.
 */
public class ControllerPostManagement {
	/** Creates the controller object. */
	public ControllerPostManagement() {}

	private static final String DELETED_POST_MESSAGE = "This post was deleted. You can still see replies";

	protected static Database database = applicationMain.FoundationsMain.database;
	
	/**
	 * Creates a new post using the values from the UI.
	 * Performs basic validation before saving.
	 */
	public static void performCreatePost() {
		int id = ModelPostManagement.getNextPostId();
		String title = ViewCreatePost.text_Title.getText(); 
		String body = ViewCreatePost.text_Body.getText();   
		String category = ViewCreatePost.combo_Category.getValue();
		String author = ViewPostManagement.theUser.getUserName();

		// Prevent empty posts from being created
		if (title.isEmpty() || body.isEmpty() || category == null || category.isEmpty()) {
			showAlert("Validation Error", "All fields including Category must be filled.");
			return;
		}
		
		// Basic length checks to match requirements
		if (title.length() > 200) {
			showAlert("Validation Error", "Title cannot exceed 200 characters");
			return;
		}
		
		if (body.length() > 5000) {
			showAlert("Validation Error", "Body cannot exceed 5000 characters");
			return;
		}

		entityClasses.Post newPost = ModelPostManagement.createPost(id, title, body, author, category);
		
		try {
			// Save to database so it persists
			database.savePost(newPost); 
			showAlert("Success", "Post created successfully!");
		} catch (java.sql.SQLException e) {
			// If DB fails, user still gets feedback
			showAlert("Database Error", "The post was created in memory but failed to save to disk.");
			e.printStackTrace();
		}
		
		// Clear fields so user can enter a new post
		ViewCreatePost.text_Title.clear();
		ViewCreatePost.text_Body.clear();
		
		ViewPostManagement.displayPostManagement(ViewPostManagement.theStage, ViewPostManagement.theUser);
	}
	
	/**
	 * Displays the selected post details in the main view.
	 */
	protected static void displaySelectedPost() {
		boolean isStaffOrAdmin = ViewPostManagement.theUser.getAdminRole() || 
                ViewPostManagement.theUser.getNewRole1(); // staff role
		
		// Get post by ID instead of relying on strings
	    entityClasses.Post p = ModelPostManagement.getPostStorage()
	            .getPostById(ViewPostManagement.currentPostId);
	    
	    if (p != null) {
	        ViewPostManagement.label_FullTitle.setText(p.isDeleted() ? DELETED_POST_MESSAGE : "Title: " + p.getTitle());
	        ViewPostManagement.label_FullAuthor.setText("Author: " + p.getAuthor());
	        ViewPostManagement.label_FullTimestamp.setText("Posted: " + p.getFormattedTimestamp());
	        ViewPostManagement.area_FullBody.setText(p.isDeleted() ? DELETED_POST_MESSAGE : p.getBody());

	        // Update reply count so user can see activity
	        int count = MVCReplyManagement.ModelReplyManagement.getReplyStorage()
	                        .getRepliesForPost(p.getId()).size();
	        ViewPostManagement.button_ViewReplies.setText("View Replies (" + count + ")");

	        // Only allow editing if user owns the post, is admin, or is staff
	        boolean canModify = ViewPostManagement.theUser.getUserName().equals(p.getAuthor()) 
	                            || ViewPostManagement.theUser.getAdminRole()
	                            || ViewPostManagement.theUser.getNewRole1();
	        ViewPostManagement.button_Edit.setVisible(canModify && !p.isDeleted());
	        ViewPostManagement.button_Delete.setVisible(canModify && !p.isDeleted());
	        
	        if (ViewPostManagement.button_Whisper != null) {
	            ViewPostManagement.button_Whisper.setVisible(isStaffOrAdmin);
	        }
	    }
	}
    
    /**
     * Opens the reply screen for the selected post.
     */
	protected static void performReply() {
        if (ViewPostManagement.currentPostId != -1) {
            MVCReplyManagement.ViewReplyManagement.displayReplyManagement(
                ViewPostManagement.theStage, 
                ViewPostManagement.theUser, 
                ViewPostManagement.currentPostId
            );
        } else {
            showAlert("Selection Error", "Please select a post before replying.");
        }
    }
    
    /**
     * Deletes the currently selected post.
     */
    protected static void performDelete() {
        int idToDelete = ViewPostManagement.currentPostId;
        
        try {
            Post post = ModelPostManagement.getPostStorage().getPostById(idToDelete);
            Alert confirm = new Alert(AlertType.CONFIRMATION);
            confirm.setTitle("Delete Post");
            confirm.setHeaderText("Are you sure?");
            confirm.setContentText("Deleting this post keeps all replies and marks the post as deleted.");

            java.util.Optional<ButtonType> result = confirm.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                post.setBody(DELETED_POST_MESSAGE);
                post.setTitle("Post Deleted");
                post.markDeleted();
                database.markPostDeleted(idToDelete, DELETED_POST_MESSAGE);
                ViewPostManagement.refreshPostList();
                displaySelectedPost();
            }
        } catch (Exception e) {
            showAlert("Error", "Could not delete post.");
        }
    }
    
    /**
     * Allows editing of the selected post body.
     */
    protected static void performEdit() {
        Post post = ModelPostManagement.getPostStorage()
                .getPostById(ViewPostManagement.currentPostId);

        if (post.isDeleted()) {
            showAlert("Error", "Deleted posts cannot be updated.");
            return;
        }

        String currentBody = post.getBody();

        javafx.scene.control.TextInputDialog dialog = 
                new javafx.scene.control.TextInputDialog(currentBody);
        dialog.setTitle("Edit Post");
        dialog.setHeaderText("Modify your post content:");
        dialog.setContentText("Body:");

        dialog.showAndWait().ifPresent(newBody -> {
            if (newBody.trim().isEmpty()) {
                showAlert("Validation Error", "Post body cannot be empty.");
            } else {
                try {
                    // Update memory version
                    post.setBody(newBody);
                    
                    // Update database version
                    database.updatePost(ViewPostManagement.currentPostId, newBody);
                    
                    // Update UI text
                    ViewPostManagement.area_FullBody.setText(post.isDeleted() ? DELETED_POST_MESSAGE : newBody);
                    showAlert("Success", "Post updated successfully!");
                } catch (java.sql.SQLException e) {
                    showAlert("Error", "Failed to save the edit to the database.");
                    e.printStackTrace();
                }
            }
        });
    }

	protected static void performBack() {
		guiRole2.ViewRole2Home.displayRole2Home(
		        ViewPostManagement.theStage, 
		        ViewPostManagement.theUser);
	}

	/**
	 * Shows a basic popup message.
	 * 
	 */
	private static void showAlert(String title, String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}
	
	/**
	 * Opens reply screen using the selected post from the list.
	 */
	protected static void performReplyToSelected() {
        String selected = ViewPostManagement.list_Posts
                .getSelectionModel().getSelectedItem();
        
        if (selected == null) {
            showAlert("Selection Error", "Please select a post from the list to reply.");
            return;
        }

        try {
            int postId = Integer.parseInt(selected.split(":")[0]);
            MVCReplyManagement.ViewReplyManagement.displayReplyManagement(
                ViewPostManagement.theStage, 
                ViewPostManagement.theUser, 
                postId);
        } catch (Exception e) {
            showAlert("Error", "Could not parse Post ID.");
        }
    }
	
	protected static void performWhisperFeedback() {
	    Post p = ModelPostManagement.getPostStorage()
	            .getPostById(ViewPostManagement.currentPostId);
	    
	    if (p == null) return;

	    // 1. Create a Dialog to get the feedback
	    javafx.scene.control.TextArea feedbackArea = new javafx.scene.control.TextArea();
	    javafx.scene.control.CheckBox anonCheck = new javafx.scene.control.CheckBox("Hide my name (Anonymous)");
	    
	    VBox content = new VBox(10); 

	 // 2. Add the components to the VBox
	    content.getChildren().addAll(
	     new Label("Provide private feedback to " + p.getAuthor() + ":"),
	     feedbackArea, 
	     anonCheck
	     );

	    Alert dialog = new Alert(AlertType.CONFIRMATION);
	    dialog.setTitle("Staff Whisper System");
	    dialog.getDialogPane().setContent(content);

	    dialog.showAndWait().ifPresent(response -> {
	        if (response == ButtonType.OK && !feedbackArea.getText().trim().isEmpty()) {
	            try {
	                String staffName = anonCheck.isSelected() ? "Anonymous Staff" : ViewPostManagement.theUser.getUserName();
	                String messageBody = "[PRIVATE FEEDBACK regarding post #" + p.getId() + "]: " + feedbackArea.getText();
	                
	                // We use the Request table to store this "Whisper" so the student can see it
	                // in their "Request Management" or "Notifications" area later.
	                database.saveRequest(
	                    "Feedback: " + p.getTitle(), 
	                    messageBody, 
	                    staffName
	                );
	                
	                showAlert("Sent", "Your feedback has been sent privately to " + p.getAuthor());
	            } catch (Exception e) {
	                showAlert("Error", "Failed to send whisper feedback.");
	            }
	        }
	    });
	}
	
	protected static void performWhisper() {
	    Post p = ModelPostManagement.getPostStorage().getPostById(ViewPostManagement.currentPostId);
	    if (p == null) return;

	    // 1. Setup UI
	    javafx.scene.control.TextArea feedbackArea = new javafx.scene.control.TextArea();
	    javafx.scene.control.CheckBox anonCheck = new javafx.scene.control.CheckBox("Hide my name (Anonymous)");
	    javafx.scene.layout.VBox content = new javafx.scene.layout.VBox(10, 
	        new javafx.scene.control.Label("Provide private feedback to " + p.getAuthor() + ":"),
	        feedbackArea, 
	        anonCheck
	    );

	    Alert dialog = new Alert(AlertType.CONFIRMATION);
	    dialog.setTitle("Staff Whisper System");
	    dialog.getDialogPane().setContent(content);

	    // 2. Handle Action
	    dialog.showAndWait().ifPresent(response -> {
	        if (response == ButtonType.OK && !feedbackArea.getText().trim().isEmpty()) {
	            try {
	                String feedback = feedbackArea.getText().trim();
	                boolean isAnon = anonCheck.isSelected();
	                
	                // Save to the postDB specifically
	                database.updatePostFeedback(p.getId(), feedback, isAnon);
	                
	                // OPTIONAL: Also save as a Request so Admins see the "Action Taken"
	                // This satisfies Gabriel/Connor's transparency requirement
	                database.saveRequest(
	                    "Feedback Sent to " + p.getAuthor(),
	                    "Staff provided feedback on post #" + p.getId() + ": " + feedback,
	                    isAnon ? "Anonymous Staff" : ViewPostManagement.theUser.getUserName()
	                );

	                showAlert("Sent", "Feedback saved successfully.");
	            } catch (SQLException e) {
	                showAlert("Error", "Database failure while sending feedback.");
	            }
	        }
	    });
	}
}
