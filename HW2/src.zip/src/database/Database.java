package database;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.time.LocalDateTime;

import entityClasses.User;

/*******
 * <p> Title: Database Class. </p>
 * * <p> Description: This is an in-memory database built on H2.  Detailed documentation of H2 can
 * be found at https://www.h2database.com/html/main.html (Click on "PDF (2MP) for a PDF of 438 pages
 * on the H2 main page.)  This class leverages H2 and provides numerous special supporting methods.
 * </p>
 * * <p> Copyright: Lynn Robert Carter © 2025 </p>
 * * @author Lynn Robert Carter
 * * @version 2.00		2025-04-29 Updated and expanded from the version produce by on a previous
 * version by Pravalika Mukkiri and Ishwarya Hidkimath Basavaraj
 * @version 2.01		2025-12-17 Minor updates for Spring 2026
 */

/*
 * The Database class is responsible for establishing and managing the connection to the database,
 * and performing operations such as user registration, login validation, handling invitation 
 * codes, and numerous other database related functions.
 */
public class Database {
	

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase112342asdfasdfqwesd342hakjassfklsjd1234123aa40a";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	//  Shared variables used within this class
	private Connection connection = null;		// Singleton to access the database 
	private Statement statement = null;			// The H2 Statement is used to construct queries
	
	// These are the easily accessible attributes of the currently logged-in user
	// This is only useful for single user applications
	private String currentUsername;
	private String currentPassword;
	private String currentFirstName;
	private String currentMiddleName;
	private String currentLastName;
	private String currentPreferredFirstName;
	private String currentEmailAddress;
	private boolean currentAdminRole;
	private boolean currentNewRole1;
	private boolean currentNewRole2;

	/*******
	 * <p> Method: Database </p>
	 * * <p> Description: The default constructor used to establish this singleton object.</p>
	 * */
	
	public Database () {
		
	}
	
	
/*******
 * <p> Method: connectToDatabase </p>
 * * <p> Description: Used to establish the in-memory instance of the H2 database from secondary
 *		storage.</p>
 *
 * @throws SQLException when the DriverManager is unable to establish a connection
 * */
	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			// statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	
/*******
 * <p> Method: createTables </p>
 * * <p> Description: Used to create new instances of the database tables used by this class.</p>
 * */
	private void createTables() throws SQLException {
		// Create the user database
		String userTable = "CREATE TABLE IF NOT EXISTS userDB ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "firstName VARCHAR(255), "
				+ "middleName VARCHAR(255), "
				+ "lastName VARCHAR (255), "
				+ "preferredFirstName VARCHAR(255), "
				+ "emailAddress VARCHAR(255), "
				+ "adminRole BOOL DEFAULT FALSE, "
				+ "newRole1 BOOL DEFAULT FALSE, "
				+ "newRole2 BOOL DEFAULT FALSE, "
				+ "isOTP BOOL DEFAULT FALSE)";
		statement.execute(userTable);
		
		// Create the posts table
		String postTable = "CREATE TABLE IF NOT EXISTS postDB ("
		    + "id INT PRIMARY KEY, "
		    + "title VARCHAR(255), "
		    + "body CLOB, "
		    + "author VARCHAR(255), "
		    + "category VARCHAR(255), "
		    + "timestamp VARCHAR(255), "
		    + "deleted BOOL DEFAULT FALSE, "
		    + "staffFeedback CLOB, "
		    + "anonymousFeedback BOOL DEFAULT FALSE)";
		statement.execute(postTable);
		
		// Create the replies table
		String replyTable = "CREATE TABLE IF NOT EXISTS replyDB ("
                + "id INT PRIMARY KEY, "
                + "postId INT, "
                + "body CLOB, "
                + "author VARCHAR(255), "
                + "timestamp VARCHAR(255))";
		statement.execute(replyTable);

		String whisperTable = "CREATE TABLE IF NOT EXISTS whisperDB ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "postId INT, "
				+ "targetUser VARCHAR(255), "
				+ "postTitle VARCHAR(255), "
				+ "staffAuthor VARCHAR(255), "
				+ "message CLOB, "
				+ "timestamp VARCHAR(255))";
		statement.execute(whisperTable);
		
		// create the request table
		String request = "CREATE TABLE IF NOT EXISTS requestDB ("
		        + "id INT AUTO_INCREMENT PRIMARY KEY, "
		        + "title VARCHAR(255), "
		        + "description CLOB, "
		        + "author VARCHAR(255), "
		        + "status VARCHAR(50) DEFAULT 'OPEN', "
		        + "resolutionNotes CLOB, "
		        + "originalRequestId INT DEFAULT NULL, "
		        + "timestamp VARCHAR(255))";
		statement.execute(request);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	    		+ "emailAddress VARCHAR(255), "
	            + "role VARCHAR(10))";
	    statement.execute(invitationCodesTable);
	    
	    String parameterTable = "CREATE TABLE IF NOT EXISTS reviewParameters ("
	         + "id INT AUTO_INCREMENT PRIMARY KEY, "
	         + "paramName VARCHAR(255), "
	         + "criteria CLOB)";
	    statement.execute(parameterTable);

	    statement.execute("ALTER TABLE postDB ADD COLUMN IF NOT EXISTS staffFeedback CLOB");
	    statement.execute("ALTER TABLE postDB ADD COLUMN IF NOT EXISTS anonymousFeedback BOOL DEFAULT FALSE");
	}
	
	/*******
	 * <p> Method: saveEvaluationParameter </p>
	 * * <p> Description: Yuvi's Story: Saves a new evaluation parameter to the database for staff use.</p>
	 * * @param name the name of the parameter
	 * @param criteria the description of the criteria
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void saveEvaluationParameter(String name, String criteria) throws SQLException {
	    String query = "INSERT INTO reviewParameters (paramName, criteria) VALUES (?, ?)";
	    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, name);
	        pstmt.setString(2, criteria);
	        pstmt.executeUpdate();
	    }
	}

	/*******
	 * <p> Method: getEvaluationParameters </p>
	 * * <p> Description: Retrieves all evaluation parameters defined by the staff.</p>
	 * * @return a list of string arrays containing the parameter name and criteria
	 * @throws SQLException when there is an issue executing the SQL query
	 */
	public List<String[]> getEvaluationParameters() throws SQLException {
	    List<String[]> list = new java.util.ArrayList<>();
	    ResultSet rs = statement.executeQuery("SELECT * FROM reviewParameters");
	    while (rs.next()) {
	        list.add(new String[]{rs.getString("paramName"), rs.getString("criteria")});
	    }
	    return list;
	}
	
	/*******
	 * <p> Method: updatePostFeedback </p>
	 * * <p> Description: Emiliano's Story: Saves private, potentially anonymous feedback to a post.</p>
	 * * @param postId the ID of the post receiving feedback
	 * @param feedback the feedback text string
	 * @param isAnonymous whether the feedback should be displayed anonymously
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void updatePostFeedback(int postId, String feedback, boolean isAnonymous) throws SQLException {
	    String query = "UPDATE postDB SET staffFeedback = ?, anonymousFeedback = ? WHERE id = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, feedback);
	        pstmt.setBoolean(2, isAnonymous);
	        pstmt.setInt(3, postId);
	        pstmt.executeUpdate();
	    }
	}

	/**
	 * Saves one whisper message for a student's post.
	 * @param postId the related post id
	 * @param targetUser the student receiving the whisper
	 * @param postTitle the title of the related post
	 * @param staffAuthor the staff user sending the whisper
	 * @param message the whisper contents
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void saveWhisper(int postId, String targetUser, String postTitle,
			String staffAuthor, String message) throws SQLException {
		String query = "INSERT INTO whisperDB (postId, targetUser, postTitle, staffAuthor, message, timestamp) "
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postId);
			pstmt.setString(2, targetUser);
			pstmt.setString(3, postTitle);
			pstmt.setString(4, staffAuthor);
			pstmt.setString(5, message);
			pstmt.setString(6, LocalDateTime.now().toString());
			pstmt.executeUpdate();
		}
	}

	/**
	 * Loads all whispers addressed to a student.
	 * @param studentUserName the student username
	 * @return the student's whispers
	 * @throws SQLException when there is an issue executing the SQL query
	 */
	public List<entityClasses.WhisperMessage> loadWhispersForStudent(String studentUserName) throws SQLException {
		List<entityClasses.WhisperMessage> whispers = new ArrayList<>();
		String query = "SELECT * FROM whisperDB WHERE targetUser = ? ORDER BY timestamp DESC";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					whispers.add(new entityClasses.WhisperMessage(
							rs.getInt("id"),
							rs.getInt("postId"),
							rs.getString("targetUser"),
							rs.getString("postTitle"),
							rs.getString("staffAuthor"),
							rs.getString("message"),
							LocalDateTime.parse(rs.getString("timestamp"))
					));
				}
			}
		}
		return whispers;
	}

	
	/**
	 * <p> Method: savePost(Post p) </p>
	 * * <p> Description: Saves a Post object into the H2 database for persistence.</p>
	 * * @param p the Post object to save
	 * @throws SQLException when there is an issue creating the SQL command or executing it
	 */
	public void savePost(entityClasses.Post p) throws SQLException {
		String query = "INSERT INTO postDB (id, title, body, author, category, timestamp, deleted) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, p.getId());
			pstmt.setString(2, p.getTitle());
			pstmt.setString(3, p.getBody());
			pstmt.setString(4, p.getAuthor());
			pstmt.setString(5, p.getCategory());
			pstmt.setString(6, p.getTimestamp().toString());
			pstmt.setBoolean(7, p.isDeleted());
			pstmt.executeUpdate();
		}
	}
    /**
     * <p> Method: saveReply(Reply r) </p>
     * * <p> Description: Saves a reply object into the H2 database </p>
     * * @param r the Reply object to save
     * @throws SQLException when there is an issue creating the SQL command or executing it
     */
	public void saveReply(entityClasses.Reply r) throws SQLException {
	    String query = "INSERT INTO replyDB (id, postId, body, author, timestamp) VALUES (?, ?, ?, ?, ?)";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setInt(1, r.getId());
	        pstmt.setInt(2, r.getParentPostId());
	        pstmt.setString(3, r.getBody());
	        pstmt.setString(4, r.getAuthor());
	        pstmt.setString(5, r.getTimestamp().toString());
	        pstmt.executeUpdate();
	    }
	}
	
    /*******
     * <p> Method: loadAllPosts() </p>
     * * <p> Load all Post records from the database.</p>
     * * @return a list of all Post objects
     * @throws SQLException when there is an issue executing the SQL query.
     */
	
	public java.util.List<entityClasses.Post> loadAllPosts() throws SQLException {
	    java.util.List<entityClasses.Post> results = new java.util.ArrayList<>();
	    String query = "SELECT * FROM postDB";
	    try (java.sql.ResultSet rs = statement.executeQuery(query)) {
	        while (rs.next()) {
	        	entityClasses.Post post = new entityClasses.Post(
	                rs.getInt("id"), rs.getString("title"), rs.getString("body"),
	                rs.getString("author"), rs.getString("category"),
	                LocalDateTime.parse(rs.getString("timestamp"))
	            );
	        	post.setStaffFeedback(rs.getString("staffFeedback"), rs.getBoolean("anonymousFeedback"));
	        	if (rs.getBoolean("deleted")) {
	        		post.markDeleted();
	        	}
	            results.add(post);
	        }
	    }
	    return results;
	}

    /*******
     * <p> Method: markPostDeleted(int id) </p>
     * * <p> Description: Marks a post as deleted without removing it from the database.</p>
     * * @param id the ID of the post to mark deleted
     * @param deletedBody the deleted message body
     * @throws SQLException when there is an issue executing the SQL command
     */
	public void markPostDeleted(int id, String deletedBody) throws java.sql.SQLException {
	    String query = "UPDATE postDB SET body = ?, deleted = TRUE WHERE id = ?";
	    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, deletedBody);
	        pstmt.setInt(2, id);
	        pstmt.executeUpdate();
	    }
	}
	

    /*******
     * <p> Method: loadAllReplies() </p>
     * * <p> Description: Load all Reply records from the database.</p>
     * * @return a list of all Reply objects
     * @throws SQLException when there is an issue executing the SQL query
     */
	public java.util.List<entityClasses.Reply> loadAllReplies() throws java.sql.SQLException {
	    java.util.List<entityClasses.Reply> results = new java.util.ArrayList<>();
	    String query = "SELECT * FROM replyDB";
	    try (java.sql.ResultSet rs = statement.executeQuery(query)) {
	        while (rs.next()) {
	            results.add(new entityClasses.Reply(
	                rs.getInt("id"), 
	                rs.getInt("postId"), 
	                rs.getString("body"),
	                rs.getString("author"),
	                LocalDateTime.parse(rs.getString("timestamp"))
	            ));
	        }
	    }
	    return results;
	}
	
    /*******
     * <p> Method: deletePost(int id) </p>
     * * <p> Description: Deletes a post by its ID and also removes all replies associated with that post.</p>
     * * @param id the ID of the post to delete
     * @throws SQLException when there is an issue executing the SQL command
     */
	public void deletePost(int id) throws java.sql.SQLException {
	    // 1. Delete the post
	    String deletePost = "DELETE FROM postDB WHERE id = ?";
	    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(deletePost)) {
	        pstmt.setInt(1, id);
	        pstmt.executeUpdate();
	    }
	    
	    // 2. NEW: Delete all replies linked to this post ID
	    String deleteReplies = "DELETE FROM replyDB WHERE postId = ?";
	    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(deleteReplies)) {
	        pstmt.setInt(1, id);
	        pstmt.executeUpdate();
	    }
	}
	
    /*******
     * <p> Method: updatePost(int id, String newBody) </p>
     * * <p> Description: Lans's Story: Updates the body of a specified post for moderation purposes.</p>
     * * @param id the post ID
     * @param newBody the new body text
     * @throws SQLException when there is an issue executing the SQL command
     */
	public void updatePost(int id, String newBody) throws java.sql.SQLException {
	    String query = "UPDATE postDB SET body = ? WHERE id = ?";
	    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, newBody);
	        pstmt.setInt(2, id);
	        pstmt.executeUpdate();
	    }
	}
	
    /*******
     * <p> Method: deleteReply(int id) </p>
     * * <p> Deletes a reply by its ID from the database.</p>
     * * @param id the reply ID
     * @throws SQLException when there is an issue executing the SQL command
     */
	public void deleteReply(int id) throws java.sql.SQLException {
        String query = "DELETE FROM replyDB WHERE id = ?";
        try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    /*******
     * <p> Method: updateReply(int id, String newBody) </p>
     * * <p> Description: Updates the body of a specified reply.</p>
     * * @param id the reply ID
     * @param newBody the new body text
     * @throws SQLException when there is an issue executing the SQL command
     */
    public void updateReply(int id, String newBody) throws java.sql.SQLException {
        String query = "UPDATE replyDB SET body = ? WHERE id = ?";
        try (java.sql.PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newBody);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        }
    }

/*******
 * <p> Method: isDatabaseEmpty </p>
 * * <p> Description: If the user database has no rows, true is returned, else false.</p>
 * * @return true if the database is empty, else it returns false
 * */
	public boolean isDatabaseEmpty() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count") == 0;
			}
		}  catch (SQLException e) {
	        return false;
	    }
		return true;
	}
	
	/*******
	 * <p> Method: getNumberOfAdmins </p>
	 * * <p> Description: Returns the number of users with administrative privileges.</p>
	 * * @return the number of admin users
	 */
	public int getNumberOfAdmins() {
	    String query = "SELECT COUNT(*) AS count FROM userDB WHERE adminRole = TRUE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getInt("count");
	        }
	    } catch (SQLException e) {
	         
	        return 0;
	    }
	    return 0;
	}

	
	
/*******
 * <p> Method: getNumberOfUsers </p>
 * * <p> Description: Returns an integer .of the number of users currently in the user database. </p>
 * * @return the number of user records in the database.
 * */
	public int getNumberOfUsers() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch (SQLException e) {
	        return 0;
	    }
		return 0;
	}

/*******
 * <p> Method: register(User user) </p>
 * * <p> Description: Creates a new row in the database using the user parameter. </p>
 * * @throws SQLException when there is an issue creating the SQL command or executing it.
 * * @param user specifies a user object to be added to the database.
 * */
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO userDB (userName, password, firstName, middleName, "
				+ "lastName, preferredFirstName, emailAddress, adminRole, newRole1, newRole2, isOTP) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			currentUsername = user.getUserName();
			pstmt.setString(1, currentUsername);
			
			currentPassword = user.getPassword();
			pstmt.setString(2, currentPassword);
			
			currentFirstName = user.getFirstName();
			pstmt.setString(3, currentFirstName);
			
			currentMiddleName = user.getMiddleName();			
			pstmt.setString(4, currentMiddleName);
			
			currentLastName = user.getLastName();
			pstmt.setString(5, currentLastName);
			
			currentPreferredFirstName = user.getPreferredFirstName();
			pstmt.setString(6, currentPreferredFirstName);
			
			currentEmailAddress = user.getEmailAddress();
			pstmt.setString(7, currentEmailAddress);
			
			currentAdminRole = user.getAdminRole();
			pstmt.setBoolean(8, currentAdminRole);
			
			currentNewRole1 = user.getNewRole1();
			pstmt.setBoolean(9, currentNewRole1);
			
			currentNewRole2 = user.getNewRole2();
			pstmt.setBoolean(10, currentNewRole2);
			
			pstmt.executeUpdate();
		}
		
	}
	
/*******
 * <p> Method: List getUserList() </p>
 * * <P> Description: Generate an List of Strings, one for each user in the database,
 * starting with {@code <Select a User>} at the start of the list. </p>
 * * @return a list of userNames found in the database.
 */
	public List<String> getUserList () {
		List<String> userList = new ArrayList<String>();
		userList.add("<Select a User>");
		String query = "SELECT userName FROM userDB";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				userList.add(rs.getString("userName"));
			}
		} catch (SQLException e) {
	        return null;
	    }
//		System.out.println(userList);
		return userList;
	}
	
	/*******
	 * <p> Method: getAllUsersForDisplay </p>
	 * * <p> Description: Returns a list of all User objects sorted by username for display purposes.</p>
	 * * @return the users for display
	 */
	public List<User> getAllUsersForDisplay() {
		List<User> users = new ArrayList<>();
		
		String query = """
			    SELECT userName, preferredFirstName, firstName, middleName, lastName,
			           emailAddress, adminRole, newRole1, newRole2
			    FROM userDB
			    ORDER BY userName
			""";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query);
		     ResultSet rs = pstmt.executeQuery()) {
		        while (rs.next()) {
		            User u = new User();
		            // Username (DO NOT overwrite later)
		            u.setUserName(rs.getString("userName"));
		            // Name parts (used by View, not stored as one field)
		            u.setPreferredFirstName(rs.getString("preferredFirstName"));
		            u.setFirstName(rs.getString("firstName"));
		            u.setMiddleName(rs.getString("middleName"));
		            u.setLastName(rs.getString("lastName"));
		            // Email
		            u.setEmailAddress(rs.getString("emailAddress"));
		            // Roles (booleans — View derives display text)
		            u.setAdminRole(rs.getBoolean("adminRole"));
		            u.setRole1User(rs.getBoolean("newRole1"));
		            u.setRole2User(rs.getBoolean("newRole2"));
		            users.add(u);
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return users;
		}



/*******
 * <p> Method: boolean loginAdmin(User user) </p>
 * * <p> Description: Check to see that a user with the specified username, password, and role
 * is the same as a row in the table for the username, password, and role. </p>
 * * @param user specifies the specific user that should be logged in playing the Admin role.
 * * @return true if the specified user has been logged in as an Admin else false.
 * */
	public boolean loginAdmin(User user){
		// Validates an admin user's login credentials so the user can login in as an Admin.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "adminRole = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();	// If a row is returned, rs.next() will return true		
		} catch  (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	
/*******
 * <p> Method: boolean loginRole1(User user) </p>
 * * <p> Description: Check to see that a user with the specified username, password, and role
 * is the same as a row in the table for the username, password, and role. </p>
 * * @param user specifies the specific user that should be logged in playing the Student role.
 * * @return true if the specified user has been logged in as an Student else false.
 * */
	public boolean loginRole1(User user) {
		// Validates a student user's login credentials.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "newRole1 = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch  (SQLException e) {
		       e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p> Method: boolean loginRole2(User user) </p>
	 * * <p> Description: Check to see that a user with the specified username, password, and role
	 * is the same as a row in the table for the username, password, and role. </p>
	 * * @param user specifies the specific user that should be logged in playing the Reviewer role.
	 * * @return true if the specified user has been logged in as an Student else false.
	 * */
	// Validates a reviewer user's login credentials.
	public boolean loginRole2(User user) {
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND "
				+ "newRole2 = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch  (SQLException e) {
		       e.printStackTrace();
		}
		return false;
	}
	
	
	/*******
	 * <p> Method: boolean doesUserExist(User user) </p>
	 * * <p> Description: Check to see that a user with the specified username is  in the table. </p>
	 * * @param userName specifies the specific user that we want to determine if it is in the table.
	 * * @return true if the specified user is in the table else false.
	 * */
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM userDB WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}

	
	/*******
	 * <p> Method: int getNumberOfRoles(User user) </p>
	 * * <p> Description: Determine the number of roles a specified user plays. </p>
	 * * @param user specifies the specific user that we want to determine if it is in the table.
	 * * @return the number of roles this user plays (0 - 5).
	 * */	
	// Get the number of roles that this user plays
	public int getNumberOfRoles (User user) {
		int numberOfRoles = 0;
		if (user.getAdminRole()) numberOfRoles++;
		if (user.getNewRole1()) numberOfRoles++;
		if (user.getNewRole2()) numberOfRoles++;
		return numberOfRoles;
	}	

	
	/*******
	 * <p> Method: String generateInvitationCode(String emailAddress, String role) </p>
	 * * <p> Description: Given an email address and a roles, this method establishes and invitation
	 * code and adds a record to the InvitationCodes table.  When the invitation code is used, the
	 * stored email address is used to establish the new user and the record is removed from the
	 * table.</p>
	 * * @param emailAddress specifies the email address for this new user.
	 * * @param role specified the role that this new user will play.
	 * * @return the code of six characters so the new user can use it to securely setup an account.
	 * */
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode(String emailAddress, String role) {
	    String code = UUID.randomUUID().toString().substring(0, 6); // Generate a random 6-character code
	    String query = "INSERT INTO InvitationCodes (code, emailaddress, role) VALUES (?, ?, ?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.setString(2, emailAddress);
	        pstmt.setString(3, role);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return code;
	}

	
	/*******
	 * <p> Method: int getNumberOfInvitations() </p>
	 * * <p> Description: Determine the number of outstanding invitations in the table.</p>
	 * * @return the number of invitations in the table.
	 * */
	// Number of invitations in the database
	public int getNumberOfInvitations() {
		String query = "SELECT COUNT(*) AS count FROM InvitationCodes";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch  (SQLException e) {
	        e.printStackTrace();
	    }
		return 0;
	}
	
	
	/*******
	 * <p> Method: boolean emailaddressHasBeenUsed(String emailAddress) </p>
	 * * <p> Description: Determine if an email address has been user to establish a user.</p>
	 * * @param emailAddress is a string that identifies a user in the table
	 * * @return true if the email address is in the table, else return false.
	 * */
	// Check to see if an email address is already in the database
	public boolean emailaddressHasBeenUsed(String emailAddress) {
	    String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE emailAddress = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, emailAddress);
	        ResultSet rs = pstmt.executeQuery();
	 //      System.out.println(rs);
	        if (rs.next()) {
	            // Mark the code as used
	        	return rs.getInt("count")>0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	
	/*******
	 * <p> Method: String getRoleGivenAnInvitationCode(String code) </p>
	 * * <p> Description: Get the role associated with an invitation code.</p>
	 * * @param code is the 6 character String invitation code
	 * * @return the role for the code or an empty string.
	 * */
	// Obtain the roles associated with an invitation code.
	public String getRoleGivenAnInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getString("role");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return "";
	}

	
	/*******
	 * <p> Method: String getEmailAddressUsingCode (String code ) </p>
	 * * <p> Description: Get the email addressed associated with an invitation code.</p>
	 * * @param code is the 6 character String invitation code
	 * * @return the email address for the code or an empty string.
	 * */
	// For a given invitation code, return the associated email address of an empty string
	public String getEmailAddressUsingCode (String code ) {
	    String query = "SELECT emailAddress FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getString("emailAddress");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return "";
	}
	
	
	/*******
	 * <p> Method: void removeInvitationAfterUse(String code) </p>
	 * * <p> Description: Remove an invitation record once it is used.</p>
	 * * @param code is the 6 character String invitation code
	 * */
	// Remove an invitation using an email address once the user account has been setup
	public void removeInvitationAfterUse(String code) {
	    String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	        	int counter = rs.getInt(1);
	            // Only do the remove if the code is still in the invitation table
	        	if (counter > 0) {
        			query = "DELETE FROM InvitationCodes WHERE code = ?";
	        		try (PreparedStatement pstmt2 = connection.prepareStatement(query)) {
	        			pstmt2.setString(1, code);
	        			pstmt2.executeUpdate();
	        		}catch (SQLException e) {
	        	        e.printStackTrace();
	        	    }
	        	}
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return;
	}
	
	
	/*******
	 * <p> Method: String getFirstName(String username) </p>
	 * * <p> Description: Get the first name of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return the first name of a user given that user's username 
	 * */
	// Get the First Name
	public String getFirstName(String username) {
		String query = "SELECT firstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("firstName"); // Return the first name if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	

	/*******
	 * <p> Method: void updateFirstName(String username, String firstName) </p>
	 * * <p> Description: Update the first name of a user given that user's username and the new
	 *		first name.</p>
	 * * @param username is the username of the user
	 * * @param firstName is the new first name for the user
	 * */
	// update the first name
	public void updateFirstName(String username, String firstName) {
	    String query = "UPDATE userDB SET firstName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, firstName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentFirstName = firstName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	/*******
	 * <p> Method: String getMiddleName(String username) </p>
	 * * <p> Description: Get the middle name of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return the middle name of a user given that user's username 
	 * */
	// get the middle name
	public String getMiddleName(String username) {
		String query = "SELECT MiddleName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("middleName"); // Return the middle name if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}

	
	/*******
	 * <p> Method: void updateMiddleName(String username, String middleName) </p>
	 * * <p> Description: Update the middle name of a user given that user's username and the new
	 * middle name.</p>
	 * * @param username is the username of the user
	 * * @param middleName is the new middle name for the user
	 * */
	// update the middle name
	public void updateMiddleName(String username, String middleName) {
	    String query = "UPDATE userDB SET middleName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, middleName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentMiddleName = middleName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getLastName(String username) </p>
	 * * <p> Description: Get the last name of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return the last name of a user given that user's username 
	 * */
	// get he last name
	public String getLastName(String username) {
		String query = "SELECT LastName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("lastName"); // Return last name role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updateLastName(String username, String lastName) </p>
	 * * <p> Description: Update the middle name of a user given that user's username and the new
	 * middle name.</p>
	 * * @param username is the username of the user
	 * * @param lastName is the new last name for the user
	 * */
	// update the last name
	public void updateLastName(String username, String lastName) {
	    String query = "UPDATE userDB SET lastName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, lastName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentLastName = lastName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getPreferredFirstName(String username) </p>
	 * * <p> Description: Get the preferred first name of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return the preferred first name of a user given that user's username 
	 * */
	// get the preferred first name
	public String getPreferredFirstName(String username) {
		String query = "SELECT preferredFirstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("firstName"); // Return the preferred first name if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updatePreferredFirstName(String username, String preferredFirstName) </p>
	 * * <p> Description: Update the preferred first name of a user given that user's username and
	 * the new preferred first name.</p>
	 * * @param username is the username of the user
	 * * @param preferredFirstName is the new preferred first name for the user
	 * */
	// update the preferred first name of the user
	public void updatePreferredFirstName(String username, String preferredFirstName) {
	    String query = "UPDATE userDB SET preferredFirstName = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, preferredFirstName);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentPreferredFirstName = preferredFirstName;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: String getEmailAddress(String username) </p>
	 * * <p> Description: Get the email address of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return the email address of a user given that user's username 
	 * */
	// get the email address
	public String getEmailAddress(String username) {
		String query = "SELECT emailAddress FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("emailAddress"); // Return the email address if user exists
	        }
			
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	
	/*******
	 * <p> Method: void updateEmailAddress(String username, String emailAddress) </p>
	 * * <p> Description: Update the email address name of a user given that user's username and
	 * the new email address.</p>
	 * * @param username is the username of the user
	 * * @param emailAddress is the new preferred first name for the user
	 * */
	// update the email address
	public void updateEmailAddress(String username, String emailAddress) {
	    String query = "UPDATE userDB SET emailAddress = ? WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, emailAddress);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	        currentEmailAddress = emailAddress;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: boolean getUserAccountDetails(String username) </p>
	 * * <p> Description: Get all the attributes of a user given that user's username.</p>
	 * * @param username is the username of the user
	 * * @return true of the get is successful, else false
	 * */
	// get the attributes for a specified user
	public boolean getUserAccountDetails(String username) {
		String query = "SELECT * FROM userDB WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();			
			rs.next();
	    	currentUsername = rs.getString(2);
	    	currentPassword = rs.getString(3);
	    	currentFirstName = rs.getString(4);
	    	currentMiddleName = rs.getString(5);
	    	currentLastName = rs.getString(6);
	    	currentPreferredFirstName = rs.getString(7);
	    	currentEmailAddress = rs.getString(8);
	    	currentAdminRole = rs.getBoolean(9);
	    	currentNewRole1 = rs.getBoolean(10);
	    	currentNewRole2 = rs.getBoolean(11);
			return true;
	    } catch (SQLException e) {
			return false;
	    }
	}
	
	/*******
	 * <p> Method: resetUserPassword </p>
	 * * <p> Description: Resets a user's password and sets the OTP flag to true.</p>
	 * * @param username the username to update
	 * @param tempPass the temporary password
	 */
	public void resetUserPassword(String username, String tempPass) {
		String query = "UPDATE userDB SET password = ?, isOTP = TRUE WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, tempPass);
	        pstmt.setString(2, username);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	/*******
	 * <p> Method: boolean updateUserRole(String username, String role, String value) </p>
	 * * <p> Description: Update a specified role for a specified user's and set and update all the
	 * current user attributes.</p>
	 * * @param username is the username of the user
	 * * @param role is string that specifies the role to update
	 * * @param value is the string that specified TRUE or FALSE for the role
	 * * @return true if the update was successful, else false
	 * */
	// Update a users role
	public boolean updateUserRole(String username, String role, String value) {
		// SAFETY: if attempting to remove Admin role, check invariants first
	    if (role.compareTo("Admin") == 0 && value.compareToIgnoreCase("false") == 0) {
	        // Prevent admin from removing their own admin role
	        if (username != null && username.equals(currentUsername)) {
	            // Do not allow current logged-in admin to remove their own Admin role
	            return false;
	        }
	        // Prevent removing last admin
	        int adminCount = getNumberOfAdmins();
	        if (adminCount <= 1) {
	            // There's only one admin — do not allow removing the admin role
	            return false;
	        }
	    }

	    // Proceed with the existing implementation (update appropriate column and update
	    // current* flags if the changed user is the currently logged-in user)
	    if (role.compareTo("Admin") == 0) {
	        String query = "UPDATE userDB SET adminRole = ? WHERE username = ?";
	        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	            pstmt.setString(1, value);
	            pstmt.setString(2, username);
	            pstmt.executeUpdate();
	            // If we changed the current user's admin role, keep the in-memory flag correct
	            if (username.equals(currentUsername)) {
	                if (value.compareToIgnoreCase("true") == 0)
	                    currentAdminRole = true;
	                else
	                    currentAdminRole = false;
	            }
	            return true;
	        } catch (SQLException e) {
	            return false;
	        }
	    }
	    if (role.compareTo("Staff") == 0) {
	        String query = "UPDATE userDB SET newRole1 = ? WHERE username = ?";
	        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	            pstmt.setString(1, value);
	            pstmt.setString(2, username);
	            pstmt.executeUpdate();
	            if (username.equals(currentUsername)) {
	                if (value.compareToIgnoreCase("true") == 0)
	                    currentNewRole1 = true;
	                else
	                    currentNewRole1 = false;
	            }
	            return true;
	        } catch (SQLException e) {
	            return false;
	        }
	    }
	    if (role.compareTo("Student") == 0) {
	        String query = "UPDATE userDB SET newRole2 = ? WHERE username = ?";
	        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	            pstmt.setString(1, value);
	            pstmt.setString(2, username);
	            pstmt.executeUpdate();
	            if (username.equals(currentUsername)) {
	                if (value.compareToIgnoreCase("true") == 0)
	                    currentNewRole2 = true;
	                else
	                    currentNewRole2 = false;
	            }
	            return true;
	        } catch (SQLException e) {
	            return false;
	        }
	    }

	    // Unknown role
	    return false;
	}
	
	/*******
	 * <p> Method: deleteUser </p>
	 * * <p> Description: Permanently removes a user record from the database, with safety checks to prevent self-deletion or leaving zero admins.</p>
	 * * @param username the username to delete
	 * @return true if the delete succeeds
	 */
	public boolean deleteUser(String username) {
	    if (username == null) return false;

	    // Prevent self-delete (current user can't delete their own account)
	    if (username.equals(currentUsername)) {
	        return false;
	    }

	    // If the user to be deleted is an admin, ensure there's at least one other admin
	    String checkAdminQuery = "SELECT adminRole FROM userDB WHERE username = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(checkAdminQuery)) {
	        pstmt.setString(1, username);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            boolean isAdmin = rs.getBoolean("adminRole");
	            if (isAdmin) {
	                int adminCount = getNumberOfAdmins();
	                if (adminCount <= 1) {
	                    // Deleting this admin would leave zero admins — disallow
	                    return false;
	                }
	            }
	        } else {
	            // User not found
	            return false;
	        }
	    } catch (SQLException e) {
	        return false;
	    }

	    // Perform the delete
	    String deleteQuery = "DELETE FROM userDB WHERE username = ?";
	    try (PreparedStatement pstmt2 = connection.prepareStatement(deleteQuery)) {
	        pstmt2.setString(1, username);
	        pstmt2.executeUpdate();
	        return true;
	    } catch (SQLException e) {
	        return false;
	    }
	}

	
	// Attribute getters for the current user
	/*******
	 * <p> Method: String getCurrentUsername() </p>
	 * * <p> Description: Get the current user's username.</p>
	 * * @return the username value is returned
	 * */
	public String getCurrentUsername() { return currentUsername;};

	
	/*******
	 * <p> Method: updatePassword </p>
	 * * <p> Description: Updates a user's password string in the database.</p>
	 * * @param username the username to update
	 * @param newPassword the new password
	 * @return true if the update succeeds
	 */
	public boolean updatePassword(String username, String newPassword) {
		// the query to change password.
		String query = "UPDATE userDB SET password = ? WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	    	pstmt.setString(1, newPassword);
		    pstmt.setString(2, username);
		    pstmt.executeUpdate();

		    // check to ensure that the username that we want to change the password for is correct.
		    if (username.equals(currentUsername)) currentPassword = newPassword;
		    	return true;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
		}
	
	/*******
	 * <p> Method: String getCurrentPassword() </p>
	 * * <p> Description: Get the current user's password.</p>
	 * * @return the password value is returned
	 * */
	public String getCurrentPassword() { return currentPassword;};

	
	/*******
	 * <p> Method: String getCurrentFirstName() </p>
	 * * <p> Description: Get the current user's first name.</p>
	 * * @return the first name value is returned
	 * */
	public String getCurrentFirstName() { return currentFirstName;};

	
	/*******
	 * <p> Method: String getCurrentMiddleName() </p>
	 * * <p> Description: Get the current user's middle name.</p>
	 * * @return the middle name value is returned
	 * */
	public String getCurrentMiddleName() { return currentMiddleName;};

	
	/*******
	 * <p> Method: String getCurrentLastName() </p>
	 * * <p> Description: Get the current user's last name.</p>
	 * * @return the last name value is returned
	 * */
	public String getCurrentLastName() { return currentLastName;};

	
	/*******
	 * <p> Method: String getCurrentPreferredFirstName( </p>
	 * * <p> Description: Get the current user's preferred first name.</p>
	 * * @return the preferred first name value is returned
	 * */
	public String getCurrentPreferredFirstName() { return currentPreferredFirstName;};

	
	/*******
	 * <p> Method: String getCurrentEmailAddress() </p>
	 * * <p> Description: Get the current user's email address name.</p>
	 * * @return the email address value is returned
	 * */
	public String getCurrentEmailAddress() { return currentEmailAddress;};

	
	/*******
	 * <p> Method: boolean getCurrentAdminRole() </p>
	 * * <p> Description: Get the current user's Admin role attribute.</p>
	 * * @return true if this user plays an Admin role, else false
	 * */
	public boolean getCurrentAdminRole() { return currentAdminRole;};

	
	/*******
	 * <p> Method: boolean getCurrentNewRole1() </p>
	 * * <p> Description: Get the current user's Student role attribute.</p>
	 * * @return true if this user plays a Student role, else false
	 * */
	public boolean getCurrentNewRole1() { return currentNewRole1;};

	
	/*******
	 * <p> Method: boolean getCurrentNewRole2() </p>
	 * * <p> Description: Get the current user's Reviewer role attribute.</p>
	 * * @return true if this user plays a Reviewer role, else false
	 * */
	public boolean getCurrentNewRole2() { return currentNewRole2;};

	
	/*******
	 * <p> Debugging method</p>
	 * * <p> Description: Debugging method that dumps the database of the console.</p>
	 * * @throws SQLException if there is an issues accessing the database.
	 * */
	// Dumps the database.
	public void dump() throws SQLException {
		String query = "SELECT * FROM userDB";
		ResultSet resultSet = statement.executeQuery(query);
		ResultSetMetaData meta = resultSet.getMetaData();
		while (resultSet.next()) {
		for (int i = 0; i < meta.getColumnCount(); i++) {
		System.out.println(
		meta.getColumnLabel(i + 1) + ": " +
				resultSet.getString(i + 1));
		}
		System.out.println();
		}
		resultSet.close();
	}
	
	/*******
	 * <p> Method: isPasswordTemporary </p>
	 * * <p> Description: Check if the user is currently flagged for a one-time password reset.</p>
	 * * @param username the username to check
	 * @return true if the password is temporary
	 */
	public boolean isPasswordTemporary(String username) {
		String query = "SELECT isOTP FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getBoolean("isOTP");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p> Method: clearOTPFlag </p>
	 * * <p> Description: Clears the OTP flag. Call this in your Update Controller after the 
     * user successfully saves their new password.</p>
	 * @param username the username to update
	 */
	public void clearOTPFlag(String username) {
		String query = "UPDATE userDB SET isOTP = FALSE WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/*******
	 * <p> Method: saveRequest </p>
	 * * <p> Description: Gabriel/Connor's Story: Saves a new staff request to the database.</p>
	 * * @param title the request title
	 * @param description the request description
	 * @param author the staff member submitting the request
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void saveRequest(String title, String description, String author) throws SQLException {
	    String query = "INSERT INTO requestDB (title, description, author, status, timestamp) "
	            + "VALUES (?, ?, ?, 'OPEN', ?)";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, title);
	        pstmt.setString(2, description);
	        pstmt.setString(3, author);
	        pstmt.setString(4, LocalDateTime.now().toString());
	        pstmt.executeUpdate();
	    }
	}

	/*******
	 * <p> Method: loadAllRequests </p>
	 * * <p> Description: Loads all staff requests from the database for admin viewing.</p>
	 * * @return a list of all requests as String arrays
	 * @throws SQLException when there is an issue executing the SQL query
	 */
	public List<String[]> loadAllRequests() throws SQLException {
	    List<String[]> results = new ArrayList<>();
	    String query = "SELECT * FROM requestDB ORDER BY id DESC";
	    try (ResultSet rs = statement.executeQuery(query)) {
	        while (rs.next()) {
	            results.add(new String[]{
	                String.valueOf(rs.getInt("id")),
	                rs.getString("title"),
	                rs.getString("description"),
	                rs.getString("author"),
	                rs.getString("status"),
	                rs.getString("resolutionNotes"),
	                String.valueOf(rs.getInt("originalRequestId")),
	                rs.getString("timestamp")
	            });
	        }
	    }
	    return results;
	}

	/*******
	 * <p> Method: closeRequest </p>
	 * * <p> Description: Closes a request and saves the admin's resolution notes.</p>
	 * * @param id the request ID to close
	 * @param resolutionNotes what the admin did to resolve it
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void closeRequest(int id, String resolutionNotes) throws SQLException {
	    String query = "UPDATE requestDB SET status = 'CLOSED', resolutionNotes = ? WHERE id = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, resolutionNotes);
	        pstmt.setInt(2, id);
	        pstmt.executeUpdate();
	    }
	}

	/*******
	 * <p> Method: reopenRequest </p>
	 * * <p> Description: Gabriel/Connor's Story: Reopens a closed request and links it to the original ID for historical tracking.</p>
	 * * @param originalId the ID of the original closed request
	 * @param description the new description explaining why it's being reopened
	 * @param author the staff member reopening it
	 * @throws SQLException when there is an issue executing the SQL command
	 */
	public void reopenRequest(int originalId, String description, String author) throws SQLException {
	    String query = "INSERT INTO requestDB (title, description, author, status, "
	            + "originalRequestId, timestamp) VALUES (?, ?, ?, 'REOPENED', ?, ?)";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, "REOPENED REQUEST #" + originalId);
	        pstmt.setString(2, description);
	        pstmt.setString(3, author);
	        pstmt.setInt(4, originalId);
	        pstmt.setString(5, LocalDateTime.now().toString());
	        pstmt.executeUpdate();
	    }
	}


	/*******
	 * <p> Method: void closeConnection()</p>
	 * * <p> Description: Closes the database statement and connection.</p>
	 * */
	// Closes the database statement and connection.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}
}
