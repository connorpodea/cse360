module EMailInputValidator {
	requires javafx.controls;
	
	opens emailAddressTestbed to javafx.graphics, javafx.fxml;
}
