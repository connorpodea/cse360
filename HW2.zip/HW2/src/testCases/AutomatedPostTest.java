package testCases;

import entityClasses.Post;
import database.Database;
import guiUserLogin.ControllerUserLogin;
import entityClasses.PostStorage;
import entityClasses.Reply;
import entityClasses.ReplyStorage;
import entityClasses.User;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * Provides automated testing for the Create and Read (CR) functionality 
 * of the Post and Reply systems. This class verifies constraints such 
 * as field length, mandatory fields, and correct object storage.
 */
public class AutomatedPostTest {

    /**
     * Executes a suite of automated tests for database. 
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {

    }
    
    /*
     * Make a valid admin login and password
      */
    @Test 
    public static void CheckSQLInjection() {
    		try {
    		// making a valid admin user
    		User user = new User("Admin", "123", "g", "g", "g", "g", "g", true, false, false);
    	
    		// call the ControllerUserLogin with the user to check if admin is valid.
    		guiUserLogin.ControllerUserLogin.validAdminUser(user);
    		}
    		
    		catch(Exception e) {
    			assertEquals(e.getMessage(), "*** Error*** This is a valid test case");
    		}
    		
    }
}
