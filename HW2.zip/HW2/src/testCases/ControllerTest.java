package testCases;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import javafx.application.Platform;
import entityClasses.User;

public class ControllerTest {

    @BeforeAll
    static void initJfx() throws Exception {
        Platform.startup(() -> {});
    }

    @Test
    public void CheckAdminValidation() {
        try {
            User user = new User("Admin", "123", "g", "g", "g", "g", "g", true, false, false);
            boolean check = guiUserLogin.ControllerUserLogin.validAdminUser(user);
            assertTrue(check);
        } catch (Exception e) {
            assertEquals(e.getMessage(), "*** Error*** This is a valid test case");
        }
    }
}
