package MVCRequestManagement;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import MVCPostManagement.ControllerPostManagement;
import MVCPostManagement.ViewPostManagement;
import entityClasses.User;

/**
 * View class for creating a new post.
 * Handles setting up the UI elements for the create post screen.
 */
public class ViewCreateRequest {
	private static double width = applicationMain.FoundationsMain.WINDOW_WIDTH;
	private static double height = applicationMain.FoundationsMain.WINDOW_HEIGHT;

	// These are accessed by the controller to read user input
	protected static TextField text_Title = new TextField();
	protected static TextArea text_Body = new TextArea();
	protected static ComboBox<String> combo_Category = new ComboBox<>();
	protected static Button button_Submit = new Button("Submit Post");
	protected static Button button_Cancel = new Button("Cancel");

	protected static Stage theStage;
	protected static User theUser;
	private static Pane theRootPane;
	private static Scene theScene;
	private static ViewCreateRequest theView;

	/**
	 * Shows the create post screen.
	 * Reuses the view so it doesn’t rebuild the UI every time.
	 * @param ps the stage for this page
	 * @param user the current user
	 */
	public static void displayCreatePost(Stage ps, User user) {
		theStage = ps;
		theUser = user;
		if (theView == null) theView = new ViewCreateRequest();
		
		theStage.setTitle("Create New Post");
		theStage.setScene(theScene);
		theStage.show();
	}

	/**
	 * Builds the layout and UI controls for creating a post.
	 */
	private ViewCreateRequest() {
		theRootPane = new Pane();
		theScene = new Scene(theRootPane, width, height);

		Label label_Title = new Label("Create a New Post");
		label_Title.setFont(Font.font("Arial", 24));
		label_Title.setLayoutX(50); label_Title.setLayoutY(30);

		// Category dropdown options
		combo_Category.getItems().addAll("Homework", "General Question", "Project", "Annoucement");
		combo_Category.setLayoutX(50); combo_Category.setLayoutY(80);
		combo_Category.setPromptText("Select Category");

		// Title input
		text_Title.setPromptText("Post Title");
		text_Title.setLayoutX(50); text_Title.setLayoutY(120);
		text_Title.setPrefWidth(width - 100);

		// Body input
		text_Body.setPromptText("Write your post here...");
		text_Body.setLayoutX(50); text_Body.setLayoutY(160);
		text_Body.setPrefSize(width - 100, height - 300);
		text_Body.setWrapText(true);

		// Buttons for submit and cancel
		button_Submit.setLayoutX(50); button_Submit.setLayoutY(height - 100);
		button_Submit.setOnAction((_) -> { ControllerPostManagement.performCreatePost(); });

		button_Cancel.setLayoutX(200); button_Cancel.setLayoutY(height - 100);
		button_Cancel.setOnAction((_) -> { ViewPostManagement.displayPostManagement(theStage, theUser); });

		theRootPane.getChildren().addAll(label_Title, combo_Category, text_Title, text_Body, button_Submit, button_Cancel);
	}
}
